package br.edu.ifnmg.marketmanagement.aplicacao;
/**
 *
 * @author guilherme
 */
public interface CategoriaRepositorio extends Repositorio<Categoria> {
    
}
