package br.edu.ifnmg.marketmanagement.aplicacao;

/**
 *
 * @author marco
 */
public interface EntregaRepositorio extends Repositorio<Entrega>{
    
}
