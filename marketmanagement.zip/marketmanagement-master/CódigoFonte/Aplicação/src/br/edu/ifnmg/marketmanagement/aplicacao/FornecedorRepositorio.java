package br.edu.ifnmg.marketmanagement.aplicacao;
/**
 *
 * @author guilherme
 */
public interface FornecedorRepositorio extends Repositorio<Fornecedor>{
    
    
    
}
