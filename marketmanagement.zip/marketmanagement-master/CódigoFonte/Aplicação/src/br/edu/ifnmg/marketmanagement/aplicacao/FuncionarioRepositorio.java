package br.edu.ifnmg.marketmanagement.aplicacao;
/**
 *
 * @author guilherme
 */
public interface FuncionarioRepositorio extends Repositorio<Funcionario> {
    
}
