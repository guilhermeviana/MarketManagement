package br.edu.ifnmg.marketmanagement.aplicacao;
/**
 *
 * @author guilherme
 */
public interface ClienteRepositorio extends Repositorio<Cliente>{
    
}
